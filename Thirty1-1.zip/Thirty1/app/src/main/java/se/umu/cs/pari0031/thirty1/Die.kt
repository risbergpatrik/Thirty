package se.umu.cs.pari0031.thirty1

import android.widget.ImageView

class Die(imageView: ImageView?) {
    var value = 0
    var image = imageView


    //Slumpar tärningens siffervärde från 1 till och med 6.
    fun randomize() {
        this.value = (1..6).random()
    }

    //Sätter tärningsbilden på en tärning utifrån vilket värde denne har och huruvida den är vald eller inte.
    fun setDieImage(dieActive: Boolean) {
        if (dieActive){
            when (value) {
                1 -> this.image?.setImageResource(R.drawable.red1)
                2 -> this.image?.setImageResource(R.drawable.red2)
                3 -> this.image?.setImageResource(R.drawable.red3)
                4 -> this.image?.setImageResource(R.drawable.red4)
                5 -> this.image?.setImageResource(R.drawable.red5)
                6 -> this.image?.setImageResource(R.drawable.red6)
                else -> {
                    print("Error")
                }
            }
        }
        else {
            when (value) {
                1 -> this.image?.setImageResource(R.drawable.white1)
                2 -> this.image?.setImageResource(R.drawable.white2)
                3 -> this.image?.setImageResource(R.drawable.white3)
                4 -> this.image?.setImageResource(R.drawable.white4)
                5 -> this.image?.setImageResource(R.drawable.white5)
                6 -> this.image?.setImageResource(R.drawable.white6)
                else -> {
                    print("Error")
                }
            }
        }
    }
}

