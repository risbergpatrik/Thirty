package se.umu.cs.pari0031.thirty1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

//Resultatsaktiviteten. Tar in värden för alla poäng och representerar dessa i textvyer.
class Result : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)
        val lowScore = findViewById<TextView>(R.id.lowScore)
        val fourScore = findViewById<TextView>(R.id.fourScore)
        val fiveScore = findViewById<TextView>(R.id.fiveScore)
        val sixScore = findViewById<TextView>(R.id.sixScore)
        val sevenScore = findViewById<TextView>(R.id.sevenScore)
        val eightScore = findViewById<TextView>(R.id.eightScore)
        val nineScore = findViewById<TextView>(R.id.nineScore)
        val tenScore = findViewById<TextView>(R.id.tenScore)
        val elevenScore = findViewById<TextView>(R.id.elevenScore)
        val twelveScore = findViewById<TextView>(R.id.twelveScore)
        val totalScore = findViewById<TextView>(R.id.totalScore)

        val score = intent.getParcelableExtra<Score>("score")

        if (score != null) {
            lowScore.text = score.low.toString()
            fourScore.text = score.four.toString()
            fiveScore.text = score.five.toString()
            sixScore.text = score.six.toString()
            sevenScore.text = score.seven.toString()
            eightScore.text = score.eight.toString()
            nineScore.text = score.nine.toString()
            tenScore.text = score.ten.toString()
            elevenScore.text = score.eleven.toString()
            twelveScore.text = score.twelve.toString()
            totalScore.text = score.total.toString()
        }
    }
}