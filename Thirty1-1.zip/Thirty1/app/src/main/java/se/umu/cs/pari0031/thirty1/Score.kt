package se.umu.cs.pari0031.thirty1

import android.os.Parcel
import android.os.Parcelable
import java.lang.System.out
import java.util.*

//En klass som håller det sparade värdet för alla poäng som räknats ihop.
class Score(var low: Int, var four: Int,
            var five: Int, var six: Int,
            var seven: Int, var eight: Int,
            var nine: Int, var ten: Int,
            var eleven: Int, var twelve: Int,
            var total: Int) : Parcelable {

    constructor(parcel: Parcel) : this(
        parcel.readInt(),
        parcel.readInt(),
        parcel.readInt(),
        parcel.readInt(),
        parcel.readInt(),
        parcel.readInt(),
        parcel.readInt(),
        parcel.readInt(),
        parcel.readInt(),
        parcel.readInt(),
        parcel.readInt()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeInt(low)
        parcel.writeInt(four)
        parcel.writeInt(five)
        parcel.writeInt(six)
        parcel.writeInt(seven)
        parcel.writeInt(eight)
        parcel.writeInt(nine)
        parcel.writeInt(ten)
        parcel.writeInt(eleven)
        parcel.writeInt(twelve)
        parcel.writeInt(total)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<Score> {
        override fun createFromParcel(parcel: Parcel): Score {
            return Score(parcel)
        }

        override fun newArray(size: Int): Array<Score?> {
            return arrayOfNulls(size)
        }
    }

    //Räknar ut poängen på tärningarna och uppdaterar den totala poängen.
    fun calculateScore(choice: String, dice: List<MainActivity.SingleDie>): Boolean {
        //Tillåter inte användaren att endast trycka på "keep all" innan några tärningar kastats.
        if (dice.any { die -> die.value == 0 }) return false
        var currentPoint = 0
        var multiplier = 0
        //Ser till att inga poäng skrivs över och att alla räknesätt används en gång var.
        when (choice) {
            "Low" -> currentPoint = this.low
            "Four" -> {
                currentPoint = this.four
                multiplier = 4}
            "Five" -> {
                currentPoint = this.five
                multiplier = 5}
            "Six" -> {
                currentPoint = this.six
                multiplier = 6}
            "Seven" -> {
                currentPoint = this.seven
                multiplier = 7}
            "Eight" -> {
                currentPoint = this.eight
                multiplier = 8}
            "Nine" -> {
                currentPoint = this.nine
                multiplier = 9}
            "Ten" -> {
                currentPoint = this.ten
                multiplier = 10}
            "Eleven" -> {
                currentPoint = this.eleven
                multiplier = 11}
            "Twelve" -> {
                currentPoint = this.twelve
                multiplier = 12}
        }
        if (currentPoint == 0) {
            /*Om det valda räknesättet är "Low" så räknas det sammanlagda värdet av alla tärningar
              som visar en trea eller lägre.*/
            if (choice == "Low") {
                var total = 0
                for (die in dice) {
                    if (die.value <= 3) {
                        total += die.value
                    }
                    this.low = total
                }
            }
            /*Har användaren valt något annat än "Low" så behöver poängen räknas på ett annat sätt.
              Tärningarna sorteras i storleksordning för att inte utesluta möjliga poäng om dessa hamnar
              i en "dålig" ordning.*/
            else {
                var dice = dice.sortedWith(compareByDescending { it.value })
                var counter = 0
                /*Logik för att räkna ut den optimala kombinationen av tärningar för att uppnå det valda talet
                så många gånger som möjligt.
                Detta använder sig av en separat lista tärningar som filter för att se till att ingen
                tärning räknas med flera gånger vid poäng.*/
                var usedDice: MutableList<MainActivity.SingleDie> = mutableListOf()
                var reroll = 0
                var i = 0
                while (i < 6) {
                    var currentDice: MutableList<MainActivity.SingleDie> = mutableListOf()
                    var sum = 0
                    var gotwin = false
                    for (die in dice) {
                        if (!usedDice.contains(die)) {
                            if (sum + die.value <= multiplier) {
                                sum += die.value
                                currentDice += die
                            }
                            if (sum == multiplier) {
                                counter++
                                usedDice += currentDice
                                gotwin = true
                                reroll = 0
                                sum = 0
                            }
                        }
                    }
                    dice = dice.minus(usedDice)
                    if (!gotwin) {
                        reroll++
                        /*Styrvariabeln "reroll" är där för att hålla koll på varje gång en loop av tärningarna inte
                    visat poäng. Är så fallet (gotwin == false) så ändras ordningen av tärningarna så att en ny tärning
                    räknas först i jämförelsen.*/
                        if (reroll < dice.size) {
                            Collections.swap(dice, 0, reroll)
                        }
                    }
                    i++
                }
                //Sätter poängen på det valda räknesättet samt adderar detta på den totala poängen.
                when (choice) {
                    "Four" -> this.four = counter * multiplier
                    "Five" -> this.five = counter * multiplier
                    "Six" -> this.six = counter * multiplier
                    "Seven" -> this.seven = counter * multiplier
                    "Eight" -> this.eight = counter * multiplier
                    "Nine" -> this.nine = counter * multiplier
                    "Ten" -> this.ten = counter * multiplier
                    "Eleven" -> this.eleven = counter * multiplier
                    "Twelve" -> this.twelve = counter * multiplier
                }
                this.total += counter * multiplier
            }
            return true
        }
        else {
            return false
        }
    }

    //Återställer poängen.
    fun resetScore() {
        this.low = 0
        this.four = 0
        this.five = 0
        this.six = 0
        this.seven = 0
        this.eight = 0
        this.nine = 0
        this.ten = 0
        this.eleven = 0
        this.twelve = 0
        this.total = 0
    }
}